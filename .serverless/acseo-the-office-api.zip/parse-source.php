<?php

$handle = @fopen("source.txt", "r");
$lines = [];
$final = [];
if ($handle) {
    while (($buffer = fgets($handle, 4096)) !== false) {
        $lines[] = $buffer;

        if (strlen(trim($buffer)) == 0) {
            //echo "BLOC DE CITATION";
            //echo "\n";
            //var_dump($lines);
            //echo "\n";
            $characters = [];
            $quote = "";
            foreach ($lines as $line) {
                if (strlen(trim($line)) > 0) {
                    $tab = explode(":", $line);
                    $characters[] = $tab[0];
                    $quote .= $line;
                }
            }
            if (strlen($quote) > 0 && sizeof($characters) > 0) {
                /*
                echo "---------------------------";
                echo "\n";
                echo "Characters : ". implode(" / ", array_unique($characters));
                echo "\n";
                echo "Quote :";
                echo "\n\n";
                echo $quote;
                echo "\n";
                */
                $final[] = [
                    "characters" => array_unique($characters),
                    "quote" => trim($quote)
                ];
            }
            $lines = [];
        }
    }
    if (!feof($handle)) {
        echo "Erreur: fgets() a échoué\n";
    }
    fclose($handle);
}

echo json_encode($final);
echo "\n";